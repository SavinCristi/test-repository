package com.vodafone.integration.tobee.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Error Object to be sent, to be set null for success response 
 */
@ApiModel(description = "Error Object to be sent, to be set null for success response ")
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-07-30T14:40:21.181Z")

public class CommonResponseError   {
  @JsonProperty("errorCode")
  private String errorCode = null;

  @JsonProperty("errorDescription")
  private String errorDescription = null;

  @JsonProperty("errorTitle")
  private String errorTitle = null;

  public CommonResponseError errorCode(String errorCode) {
    this.errorCode = errorCode;
    return this;
  }

  /**
   * error code
   * @return errorCode
  **/
  @ApiModelProperty(example = "xxx", value = "error code")


  public String getErrorCode() {
    return errorCode;
  }

  public void setErrorCode(String errorCode) {
    this.errorCode = errorCode;
  }

  public CommonResponseError errorDescription(String errorDescription) {
    this.errorDescription = errorDescription;
    return this;
  }

  /**
   * description for error
   * @return errorDescription
  **/
  @ApiModelProperty(value = "description for error")


  public String getErrorDescription() {
    return errorDescription;
  }

  public void setErrorDescription(String errorDescription) {
    this.errorDescription = errorDescription;
  }

  public CommonResponseError errorTitle(String errorTitle) {
    this.errorTitle = errorTitle;
    return this;
  }

  /**
   * error title
   * @return errorTitle
  **/
  @ApiModelProperty(value = "error title")


  public String getErrorTitle() {
    return errorTitle;
  }

  public void setErrorTitle(String errorTitle) {
    this.errorTitle = errorTitle;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CommonResponseError commonResponseError = (CommonResponseError) o;
    return Objects.equals(this.errorCode, commonResponseError.errorCode) &&
        Objects.equals(this.errorDescription, commonResponseError.errorDescription) &&
        Objects.equals(this.errorTitle, commonResponseError.errorTitle);
  }

  @Override
  public int hashCode() {
    return Objects.hash(errorCode, errorDescription, errorTitle);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CommonResponseError {\n");
    
    sb.append("    errorCode: ").append(toIndentedString(errorCode)).append("\n");
    sb.append("    errorDescription: ").append(toIndentedString(errorDescription)).append("\n");
    sb.append("    errorTitle: ").append(toIndentedString(errorTitle)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

