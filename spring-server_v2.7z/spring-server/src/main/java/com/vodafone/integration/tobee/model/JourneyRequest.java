package com.vodafone.integration.tobee.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.vodafone.integration.tobee.model.JourneyObject;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * api invocation metadata values
 */
@ApiModel(description = "api invocation metadata values")
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-07-30T14:40:21.181Z")

public class JourneyRequest   {
  @JsonProperty("methodName")
  private String methodName = null;

  @JsonProperty("input")
  @Valid
  private Map<String, JourneyObject> input = new HashMap<String, JourneyObject>();

  @JsonProperty("metaDataForHeaders")
  @Valid
  private Map<String, String> metaDataForHeaders = null;

  public JourneyRequest methodName(String methodName) {
    this.methodName = methodName;
    return this;
  }

  /**
   * method or operation name to be invoked on journey service, maps to method name received from bot
   * @return methodName
  **/
  @ApiModelProperty(required = true, value = "method or operation name to be invoked on journey service, maps to method name received from bot")
  @NotNull


  public String getMethodName() {
    return methodName;
  }

  public void setMethodName(String methodName) {
    this.methodName = methodName;
  }

  public JourneyRequest input(Map<String, JourneyObject> input) {
    this.input = input;
    return this;
  }

  public JourneyRequest putInputItem(String key, JourneyObject inputItem) {
    this.input.put(key, inputItem);
    return this;
  }

  /**
   * linked hashmap containing input parameters of the method with corresponding values, would contain atleast a msisdn
   * @return input
  **/
  @ApiModelProperty(required = true, value = "linked hashmap containing input parameters of the method with corresponding values, would contain atleast a msisdn")
  @NotNull

  @Valid

  public Map<String, JourneyObject> getInput() {
    return input;
  }

  public void setInput(Map<String, JourneyObject> input) {
    this.input = input;
  }

  public JourneyRequest metaDataForHeaders(Map<String, String> metaDataForHeaders) {
    this.metaDataForHeaders = metaDataForHeaders;
    return this;
  }

  public JourneyRequest putMetaDataForHeadersItem(String key, String metaDataForHeadersItem) {
    if (this.metaDataForHeaders == null) {
      this.metaDataForHeaders = new HashMap<String, String>();
    }
    this.metaDataForHeaders.put(key, metaDataForHeadersItem);
    return this;
  }

  /**
   * metadata which can be used either as header or some key value pairs while communicating with functional/csm service,
   * @return metaDataForHeaders
  **/
  @ApiModelProperty(value = "metadata which can be used either as header or some key value pairs while communicating with functional/csm service,")


  public Map<String, String> getMetaDataForHeaders() {
    return metaDataForHeaders;
  }

  public void setMetaDataForHeaders(Map<String, String> metaDataForHeaders) {
    this.metaDataForHeaders = metaDataForHeaders;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    JourneyRequest journeyRequest = (JourneyRequest) o;
    return Objects.equals(this.methodName, journeyRequest.methodName) &&
        Objects.equals(this.input, journeyRequest.input) &&
        Objects.equals(this.metaDataForHeaders, journeyRequest.metaDataForHeaders);
  }

  @Override
  public int hashCode() {
    return Objects.hash(methodName, input, metaDataForHeaders);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class JourneyRequest {\n");
    
    sb.append("    methodName: ").append(toIndentedString(methodName)).append("\n");
    sb.append("    input: ").append(toIndentedString(input)).append("\n");
    sb.append("    metaDataForHeaders: ").append(toIndentedString(metaDataForHeaders)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

