package com.vodafone.integration.tobee.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * api invocation metadata values with type
 */
@ApiModel(description = "api invocation metadata values with type")
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-07-30T14:40:21.181Z")

public class JourneyObject   {
  @JsonProperty("value")
  private Object value = null;

  @JsonProperty("objectType")
  private String objectType = null;

  public JourneyObject value(Object value) {
    this.value = value;
    return this;
  }

  /**
   * parameter value
   * @return value
  **/
  @ApiModelProperty(example = "9891289892", required = true, value = "parameter value")
  @NotNull


  public Object getValue() {
    return value;
  }

  public void setValue(Object value) {
    this.value = value;
  }

  public JourneyObject objectType(String objectType) {
    this.objectType = objectType;
    return this;
  }

  /**
   * parameter type
   * @return objectType
  **/
  @ApiModelProperty(example = "java.lang.String", value = "parameter type")


  public String getObjectType() {
    return objectType;
  }

  public void setObjectType(String objectType) {
    this.objectType = objectType;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    JourneyObject journeyObject = (JourneyObject) o;
    return Objects.equals(this.value, journeyObject.value) &&
        Objects.equals(this.objectType, journeyObject.objectType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(value, objectType);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class JourneyObject {\n");
    
    sb.append("    value: ").append(toIndentedString(value)).append("\n");
    sb.append("    objectType: ").append(toIndentedString(objectType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

