package com.vodafone.integration.tobee.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Translated CSM ZA Response to be returned by journey microservice 
 */
@ApiModel(description = "Translated CSM ZA Response to be returned by journey microservice ")
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-07-30T14:40:21.181Z")

public class JourneyResponse   {
  @JsonProperty("response")
  @Valid
  private Map<String, Object> response = null;

  public JourneyResponse response(Map<String, Object> response) {
    this.response = response;
    return this;
  }

  public JourneyResponse putResponseItem(String key, Object responseItem) {
    if (this.response == null) {
      this.response = new HashMap<String, Object>();
    }
    this.response.put(key, responseItem);
    return this;
  }

  /**
   * response key value pairs
   * @return response
  **/
  @ApiModelProperty(value = "response key value pairs")


  public Map<String, Object> getResponse() {
    return response;
  }

  public void setResponse(Map<String, Object> response) {
    this.response = response;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    JourneyResponse journeyResponse = (JourneyResponse) o;
    return Objects.equals(this.response, journeyResponse.response);
  }

  @Override
  public int hashCode() {
    return Objects.hash(response);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class JourneyResponse {\n");
    
    sb.append("    response: ").append(toIndentedString(response)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

