/**
 * 
 */
package com.vodafone.integration.tobee.subscription.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * @author mipopesc
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class LineItem {
	
	@JsonProperty("id")
	private List<ID> id;
	
	@JsonProperty("name")
	private String name;
	
	@JsonProperty("type")
	private String type;

	public List<ID> getId() {
		return id;
	}

	public void setId(List<ID> id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "LineItem [id=" + id.toString() + ", name=" + name + ", type=" + type + "]";
	}
	
	

}
