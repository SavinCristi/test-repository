/**
 * 
 */
package com.vodafone.integration.tobee.subscription.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author mipopesc
 *
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class LineItemContainer {
	
	@JsonProperty("lineItem")
	private List<LineItem> lineItem;

	public List<LineItem> getLineItem() {
		return lineItem;
	}

	public void setLineItem(List<LineItem> lineItem) {
		this.lineItem = lineItem;
	}

	@Override
	public String toString() {
		return "LineItemContainer [lineItem=" + lineItem.toString() + "]";
	}
	
	
}
