/**
 * 
 */
package com.vodafone.integration.tobee.subscription.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author mipopesc
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ID {

	@JsonProperty("schemeAgencyName")
	private String schemeAgencyName;
	
	@JsonProperty("schemeName")
	private String schemeName;
	
	@JsonProperty("value")
	private String value;

	public String getSchemeAgencyName() {
		return schemeAgencyName;
	}

	public void setSchemeAgencyName(String schemeAgencyName) {
		this.schemeAgencyName = schemeAgencyName;
	}

	public String getSchemeName() {
		return schemeName;
	}

	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return "ID [schemeAgencyName=" + schemeAgencyName + ", schemeName=" + schemeName + ", value=" + value + "]";
	}
	
	
}
