package com.vodafone.integration.tobee.api;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vodafone.integration.tobee.model.JourneyRequest;
import com.vodafone.integration.tobee.model.JourneyResponse;
import com.vodafone.integration.tobee.subscription.model.LineItemContainer;

import io.swagger.annotations.ApiParam;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-07-30T14:40:21.181Z")

@Controller
public class InvokeApiController implements InvokeApi {

	private static final Logger log = LoggerFactory.getLogger(InvokeApiController.class);

	private final ObjectMapper objectMapper;

	private final HttpServletRequest request;

	@Value("${service.serviceUrl}")
	private String serviceUrl;

	@org.springframework.beans.factory.annotation.Autowired
	public InvokeApiController(ObjectMapper objectMapper, HttpServletRequest request) {
		this.objectMapper = objectMapper;
		this.request = request;
	}

	public ResponseEntity<JourneyResponse> invokeApiPost(
			@ApiParam(value = "journeyRequest", required = true) @Valid @RequestBody JourneyRequest journeyRequest) {
		try {
			Map<String, Object> responseMap = new HashMap<String, Object>();
			responseMap.put("additionalProp1", "object1");
			responseMap.put("additionalProp2", "object2");
			JourneyResponse journeyResponse = new JourneyResponse();

			log.info("${service.serviceUrl}=" + serviceUrl);
			journeyResponse.response(responseMap);
			callCSMService(journeyRequest, journeyResponse);

			return new ResponseEntity<JourneyResponse>(journeyResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Internal Server Error ", e);
			return new ResponseEntity<JourneyResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	private void callCSMService(JourneyRequest journeyRequest, JourneyResponse journeyResponse) {

		journeyRequest.getInput().entrySet();

		RestTemplate restTemplate = new RestTemplate();

		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		//HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		String requestJson = createRequestJson(journeyRequest);
		HttpEntity<String> entity = new HttpEntity<String>(requestJson, headers);
		ResponseEntity<LineItemContainer> result = restTemplate.exchange(serviceUrl, HttpMethod.POST, entity, LineItemContainer.class);
		log.info("CSM service response" + result.toString()) ;
	}

	private String createRequestJson(JourneyRequest journeyRequest) {
		String request = "{\n" + 
		"    \"queryOptions\": {\n" + 
		"        \"filter\": \"\",\n" + 
		"        \"pagination\": {\n" + 
		"            \"count\": 0,\n" + 
		"            \"limit\": 0\n" + 
		"        },\n" + 
		"        \"sorting\": \"-$.type\"\n" + 
		"    },\n" + 
		"    \"queries\": [\n" + 
		"        {\n" + 
		"            \"query\": \"   $.details.msisdn = 734355601\"\n" + 
		"        }\n" + 
		"    ]\n" + 
		"}";
		
		return request;
	}

	/*
	 * public ResponseEntity<JourneyResponse> invokeApiPost(@ApiParam(value =
	 * "journeyRequest" ,required=true ) @Valid @RequestBody JourneyRequest
	 * journeyRequest) { String accept = request.getHeader("Accept"); if (accept !=
	 * null && accept.contains("")) { try { return new
	 * ResponseEntity<JourneyResponse>(objectMapper.readValue("",
	 * JourneyResponse.class), HttpStatus.NOT_IMPLEMENTED); } catch (IOException e)
	 * { log.error("Couldn't serialize response for content type ", e); return new
	 * ResponseEntity<JourneyResponse>(HttpStatus.INTERNAL_SERVER_ERROR); } }
	 * 
	 * return new ResponseEntity<JourneyResponse>(HttpStatus.NOT_IMPLEMENTED); }
	 */

}
